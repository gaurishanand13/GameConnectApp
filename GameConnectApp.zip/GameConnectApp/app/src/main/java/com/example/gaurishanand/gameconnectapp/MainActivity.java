package com.example.gaurishanand.gameconnectapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int activePlayer=1;
    int winningPositions[][]={{1,2,3},{4,5,6},{7,8,9},{1,4,7},{2,5,8},{3,6,9},{1,5,9},{3,5,7}};
    int arr[]={0,0,0,0,0,0,0,0,0};
    boolean activeGame=true;
    public void clickFunction(View view)
    {
        ImageView imageView=(ImageView) view;
        int TappedCounter=Integer.parseInt(imageView.getTag().toString());
        if(arr[TappedCounter-1]==0 && activeGame)
        {
            arr[TappedCounter-1]=activePlayer;
            if(activePlayer==1)
            {
                activePlayer=2;
                imageView.setImageResource(R.drawable.cross);
            }
            else
            {
                activePlayer=1;
                imageView.setImageResource(R.drawable.circle);
            }
            for(int i=0;i<8;i++)
            {
                    if(arr[winningPositions[i][0]-1]==arr[winningPositions[i][1]-1]&&arr[winningPositions[i][1]-1]==arr[winningPositions[i][2]-1]&&arr[winningPositions[i][0]-1]!=0)
                    {
                        String ans;
                        if(activePlayer==1)
                        {
                            ans="PLAYER 2";
                        }
                        else
                        {
                            ans="PLAYER 1";
                        }
                        activeGame=false;
                        TextView textView=(TextView)findViewById(R.id.textView2);
                        Button button=(Button)findViewById(R.id.button) ;
                        textView.setText(ans+" HAS WON");
                        button.setVisibility(View.VISIBLE);
                        textView.setVisibility(View.VISIBLE);

                    }
            }
            int c=1;
            for(int i=0;i<9;i++)
            {
                if(arr[i]==0)
                {
                    c=2;
                    break;
                }
            }
            if(c==1)
            {
                activeGame=false;
                TextView textView=(TextView)findViewById(R.id.textView2);
                Button button=(Button)findViewById(R.id.button) ;
                textView.setText("MATCH IS DRAWN");
                button.setVisibility(View.VISIBLE);
                textView.setVisibility(View.VISIBLE);
            }
        }

    }
    public void playagain(View view)
    {
        TextView textView=(TextView)findViewById(R.id.textView2);
        Button button=(Button)findViewById(R.id.button) ;
        button.setVisibility(View.INVISIBLE);
        textView.setVisibility(View.INVISIBLE);
        for(int i=0;i<9;i++)
        {
            arr[i]=0;
        }
        activePlayer=1;
        activeGame=true;
        //to travel all the views in a grid layout
        GridLayout gridLayout=(GridLayout)findViewById(R.id.myGridLayout);
        for(int i = 0 ; i <gridLayout.getChildCount() ; i++){
            View child = gridLayout.getChildAt(i);
            ImageView imageView=(ImageView)child;
            imageView.setBackground(R.drawable.circle);
        }
    }
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
